# Smart Canteen Management System
1. Firebase console (project smartcanteen-84737): enable **Authentication → Email/Password**, create **Firestore** and **Storage**.
2. Paste `firestore.rules` into Firestore → Rules, and `storage.rules` into Storage → Rules. Publish.
3. Serve this folder over HTTP (ES modules don't work from file://): `python3 -m http.server 8000` → http://localhost:8000
   (add `localhost` under Authentication → Settings → Authorized domains if needed).
4. Register an account on the site, then in Firestore open `users/<your uid>` and change `role` from `user` to `admin`. Log in again → admin panel.
5. Add menu items (or import Excel). Customers register themselves.
Menu card PDF: Admin → Menu Card → Print → "Save as PDF".
