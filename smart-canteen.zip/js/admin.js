import {auth,db,guard,$,esc,toast,go,tabs,collection,onSnapshot,addDoc,updateDoc,deleteDoc,doc,serverTimestamp,signOut} from "./firebase.js";
import {getStorage,ref,uploadBytes,getDownloadURL} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";
let menu=[],orders=[],users=[],parsed=[],ch={},firstO=true;
const ms=o=>o.createdAt?.toMillis?.()||Date.now(),key=d=>new Date(d).toLocaleDateString('en-CA');
tabs();$('#out').onclick=()=>signOut(auth).then(()=>location='index.html');
guard('admin',()=>{
 onSnapshot(collection(db,'menuItems'),s=>{menu=s.docs.map(d=>({id:d.id,...d.data()}));rMenu();rDash()});
 onSnapshot(collection(db,'orders'),s=>{if(!firstO)s.docChanges().forEach(c=>c.type=='added'&&toast('🔔 New order '+c.doc.data().orderNo,'info'));firstO=false;
  orders=s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>ms(b)-ms(a));rOrders();rDash();rAna();rCust()});
 onSnapshot(collection(db,'users'),s=>{users=s.docs.map(d=>({id:d.id,...d.data()}));rCust();rDash()})});
/* ---------- Dashboard ---------- */
function rDash(){const t=key(Date.now()),o=orders.filter(x=>key(ms(x))==t),ok=o.filter(x=>x.status!='cancelled'),n=s=>o.filter(x=>s.includes(x.status)).length;
 const pr=orders.filter(x=>x.readyAt&&x.status!='cancelled').map(x=>(x.readyAt-ms(x))/6e4),avg=pr.length?(pr.reduce((a,b)=>a+b)/pr.length).toFixed(1)+' min':'—';
 const cnt={};ok.forEach(x=>x.items.forEach(i=>cnt[i.name]=(cnt[i.name]||0)+i.qty));const pop=Object.entries(cnt).sort((a,b)=>b[1]-a[1])[0];
 const S=[['Orders today',o.length],['Revenue today','₹'+ok.reduce((a,x)=>a+x.total,0)],['Customers',users.filter(u=>u.role=='user').length],['Pending',n(['placed','confirmed','preparing'])],['Completed',n(['completed'])],['Cancelled',n(['cancelled'])],['Popular today',pop?pop[0]:'—'],['Avg prep time',avg]];
 $('#stats').innerHTML=S.map(s=>`<div class="col-6 col-lg-3"><div class="card stat p-3"><div class="text-muted small">${s[0]}</div><h4>${esc(s[1])}</h4></div></div>`).join('');
 const un=menu.filter(m=>!m.available);$('#alerts').innerHTML=un.length?`<div class="alert alert-warning">⚠️ Unavailable items: ${un.map(m=>esc(m.name)).join(', ')}</div>`:''}
/* ---------- Menu CRUD ---------- */
function rMenu(){$('#mbody').innerHTML=menu.map(m=>`<tr><td><img src="${esc(m.imageUrl||'https://placehold.co/50')}" width="50" height="50" class="rounded" style="object-fit:cover"></td><td>${esc(m.name)} ${m.special?'⭐':''}</td><td>${esc(m.category)}</td><td>₹${m.price}</td><td>${m.date||'Every day'}</td><td><div class="form-check form-switch"><input class="form-check-input" type="checkbox" data-av="${m.id}" ${m.available?'checked':''}></div></td><td><button class="btn btn-sm btn-outline-primary" data-ed="${m.id}"><i class="bi bi-pencil"></i></button> <button class="btn btn-sm btn-outline-danger" data-rm="${m.id}"><i class="bi bi-trash"></i></button></td></tr>`).join('')||'<tr><td colspan=7 class="empty">No items yet</td></tr>';
 const cats=[...new Set(menu.map(m=>m.category))].sort(),v=$('#xcat').value;$('#xcat').innerHTML='<option value="">All categories</option>'+cats.map(c=>`<option>${esc(c)}</option>`).join('');$('#xcat').value=v;
 $('#mcard').innerHTML='<h2 class="text-center">🍽️ Canteen Menu</h2>'+cats.map(c=>`<h3>${esc(c)}</h3>`+menu.filter(m=>m.category==c&&m.available).map(m=>`<div class="d-flex gap-3 my-2 align-items-center">${m.imageUrl?`<img src="${esc(m.imageUrl)}" width="60" height="60" class="rounded" style="object-fit:cover">`:''}<div class="flex-grow-1"><b>${esc(m.name)}</b><div class="small text-muted">${esc(m.description)}</div></div><b>₹${m.price}</b></div>`).join('')).join('')}
$('#mbody').addEventListener('click',async e=>{const b=e.target.closest('[data-ed],[data-rm]');if(!b)return;
 if(b.dataset.rm){if(confirm('Delete this item?'))try{await deleteDoc(doc(db,'menuItems',b.dataset.rm));toast('Deleted')}catch(err){toast(err.message,'danger')}}
 else{const m=menu.find(x=>x.id==b.dataset.ed);mid.value=m.id;mname.value=m.name;mcat.value=m.category;mprice.value=m.price;mdesc.value=m.description;mav.checked=!!m.available;msp.checked=!!m.special;mdate.value=m.date||'';scrollTo(0,0)}});
$('#mbody').addEventListener('change',e=>{if(e.target.dataset.av)updateDoc(doc(db,'menuItems',e.target.dataset.av),{available:e.target.checked}).catch(err=>toast(err.message,'danger'))});
$('#mf').onsubmit=async e=>{e.preventDefault();const b=$('#msave');b.disabled=true;
 try{const id=$('#mid').value,d={name:mname.value.trim(),category:mcat.value.trim(),price:+mprice.value,description:mdesc.value.trim(),available:mav.checked,special:msp.checked,date:mdate.value||null};
  if(!(d.price>0))throw Error('Invalid price');const f=mimg.files[0];
  if(f){const r=ref(getStorage(),`menu/${Date.now()}_${f.name}`);await uploadBytes(r,f);d.imageUrl=await getDownloadURL(r)}
  if(id)await updateDoc(doc(db,'menuItems',id),d);else await addDoc(collection(db,'menuItems'),{imageUrl:'',...d,createdAt:serverTimestamp()});
  e.target.reset();mid.value='';toast('Saved')}catch(err){toast(err.message,'danger')}b.disabled=false};
/* ---------- Excel ---------- */
$('#tpl').onclick=()=>{const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([['Name','Category','Price','Description','Available','Date'],['Veg Sandwich','Snacks',40,'Grilled sandwich','Yes','']]),'Menu');XLSX.writeFile(wb,'menu_template.xlsx')};
$('#xfile').onchange=async e=>{const f=e.target.files[0];if(!f)return;
 try{const wb=XLSX.read(await f.arrayBuffer()),rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:''}),seen=new Set(menu.map(m=>m.name.toLowerCase()));
  parsed=rows.map((r,i)=>{const g=k=>String(r[k]??'').trim(),err=[],name=g('Name'),cat=g('Category'),price=Number(g('Price')),desc=g('Description'),av=g('Available').toLowerCase();
   if(!name)err.push('Missing name');if(!cat)err.push('Missing category');if(!(price>0))err.push('Invalid price');if(!desc)err.push('Missing description');
   if(!['yes','no','true','false','1','0'].includes(av))err.push('Available must be Yes/No');
   if(name&&seen.has(name.toLowerCase()))err.push('Duplicate item');seen.add(name.toLowerCase());
   return{row:i+2,err,d:{name,category:cat,price,description:desc,available:['yes','true','1'].includes(av),special:false,date:g('Date')||null,imageUrl:''}}});
  const ok=parsed.filter(p=>!p.err.length).length;$('#doimp').disabled=!ok;$('#xsum').innerHTML=`<div class="alert alert-info">${ok} valid, ${parsed.length-ok} with errors</div>`;
  $('#xprev').innerHTML='<tr><th>Row</th><th>Name</th><th>Category</th><th>Price</th><th>Status</th></tr>'+parsed.map(p=>`<tr class="${p.err.length?'table-danger':''}"><td>${p.row}</td><td>${esc(p.d.name)}</td><td>${esc(p.d.category)}</td><td>${p.d.price}</td><td>${p.err.length?esc(p.err.join(', ')):'OK'}</td></tr>`).join('')}
 catch(err){toast('Cannot read file: '+err.message,'danger')}};
$('#doimp').onclick=async()=>{const b=$('#doimp');b.disabled=true;const v=parsed.filter(p=>!p.err.length);
 const r=await Promise.allSettled(v.map(p=>addDoc(collection(db,'menuItems'),{...p.d,createdAt:serverTimestamp()})));const ok=r.filter(x=>x.status=='fulfilled').length;
 $('#xsum').innerHTML=`<div class="alert alert-success">Imported ${ok}. Failed: ${parsed.length-ok} (invalid or rejected).</div>`;parsed=[];$('#xprev').innerHTML='';$('#xfile').value=''};
$('#xexp').onclick=()=>{const c=$('#xcat').value,d=$('#xdate').value,l=menu.filter(m=>(!c||m.category==c)&&(!d||!m.date||m.date==d));
 if(!l.length)return toast('Nothing to export','warning');const wb=XLSX.utils.book_new();
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(l.map(m=>({Name:m.name,Category:m.category,Price:m.price,Description:m.description,Available:m.available?'Yes':'No',Date:m.date||''}))),'Menu');XLSX.writeFile(wb,`menu${d?'_'+d:''}.xlsx`)};
/* ---------- Orders ---------- */
['osr','ost','odt'].forEach(i=>$('#'+i).oninput=rOrders);
function rOrders(){const q=$('#osr').value.toLowerCase(),s=$('#ost').value,d=$('#odt').value;
 const l=orders.filter(o=>(!s||o.status==s)&&(!d||key(ms(o))==d)&&(o.orderNo+' '+o.userName).toLowerCase().includes(q));
 $('#obody').innerHTML=l.length?l.map(o=>`<div class="card p-3 mb-2"><div class="d-flex justify-content-between flex-wrap"><div><b>${o.orderNo}</b> · ${esc(o.userName)} <span class="text-muted small">${new Date(ms(o)).toLocaleString()}</span></div><span class="badge bg-secondary">${o.status}</span></div>
 <div class="small my-1">${o.items.map(i=>`${esc(i.name)}×${i.qty}`).join(', ')} — <b>₹${o.total}</b>${o.note?` · Note: ${esc(o.note)}`:''}${o.cancelReason?` · <span class="text-danger">${esc(o.cancelReason)}</span>`:''}</div>
 ${['completed','cancelled'].includes(o.status)?'':`<div class="d-flex flex-wrap gap-2 align-items-center">${o.status=='placed'?`<button class="btn btn-sm btn-success" data-s="confirmed" data-o="${o.id}">Accept</button>`:''}<select class="form-select form-select-sm w-auto" data-sel="${o.id}">${['placed','confirmed','preparing','ready','completed'].map(x=>`<option ${x==o.status?'selected':''}>${x}</option>`).join('')}</select><input type="number" min="1" id="eta-${o.id}" class="form-control form-control-sm" style="width:90px" placeholder="ETA min" value="${o.etaMinutes??''}"><button class="btn btn-sm btn-outline-primary" data-eta="${o.id}">Set ETA</button><button class="btn btn-sm btn-outline-danger" data-x="${o.id}">${o.status=='placed'?'Reject':'Cancel'}</button></div>`}</div>`).join(''):'<div class="empty">No orders</div>'}
const setSt=(id,s)=>updateDoc(doc(db,'orders',id),{status:s,...(['ready','completed'].includes(s)?{readyAt:Date.now()}:{})}).then(()=>toast('Status: '+s)).catch(e=>toast(e.message,'danger'));
$('#obody').addEventListener('change',e=>{if(e.target.dataset.sel)setSt(e.target.dataset.sel,e.target.value)});
$('#obody').addEventListener('click',async e=>{const b=e.target.closest('[data-s],[data-eta],[data-x]');if(!b)return;
 if(b.dataset.s)setSt(b.dataset.o,b.dataset.s);
 else if(b.dataset.eta){const v=+$('#eta-'+b.dataset.eta).value;if(!(v>0))return toast('Enter minutes','warning');updateDoc(doc(db,'orders',b.dataset.eta),{etaMinutes:v,etaSetAt:Date.now()}).then(()=>toast('ETA updated')).catch(err=>toast(err.message,'danger'))}
 else{const r=prompt('Cancellation reason (required):');if(!r?.trim())return;updateDoc(doc(db,'orders',b.dataset.x),{status:'cancelled',cancelReason:r.trim()}).then(()=>toast('Order cancelled')).catch(err=>toast(err.message,'danger'))}});
/* ---------- Analytics ---------- */
['rng','from','to'].forEach(i=>$('#'+i).oninput=rAna);
function rng(){const v=$('#rng').value,t=new Date();t.setHours(0,0,0,0);let a=t,b=new Date(+t+864e5);
 if(v=='yest'){a=new Date(+t-864e5);b=t}else if(v=='7')a=new Date(+t-6*864e5);else if(v=='30')a=new Date(+t-29*864e5);
 else if(v=='custom'){if(!$('#from').value||!$('#to').value)return[a,b];a=new Date($('#from').value+'T00:00');b=new Date(+new Date($('#to').value+'T00:00')+864e5)}return[a,b]}
function mk(id,type,labels,data,label,h){ch[id]?.destroy();const pal=['#ff6b35','#ffb347','#4caf50','#2196f3','#9c27b0','#795548','#e91e63'];
 ch[id]=new Chart($('#'+id),{type,data:{labels,datasets:[{label,data,backgroundColor:type=='doughnut'?pal:'#ff6b35',borderColor:'#ff6b35',tension:.3}]},options:{indexAxis:h?'y':'x',plugins:{legend:{display:type=='doughnut'}}}})}
let rep={};
function rAna(){const[a,b]=rng(),all=orders.filter(o=>ms(o)>=a&&ms(o)<b),ok=all.filter(o=>o.status!='cancelled');
 const days={};for(let d=new Date(a);d<b;d=new Date(+d+864e5))days[key(d)]={rev:0,n:0};ok.forEach(o=>{const k=key(ms(o));days[k].rev+=o.total;days[k].n++});
 const it={},cat={},hr=Array(24).fill(0),cu={};ok.forEach(o=>{cu[o.userName]=(cu[o.userName]||0)+o.total;hr[new Date(ms(o)).getHours()]++;o.items.forEach(i=>{it[i.name]=(it[i.name]||0)+i.qty;cat[i.category]=(cat[i.category]||0)+i.qty})});
 const top=Object.entries(it).sort((x,y)=>y[1]-x[1]),pr=ok.filter(o=>o.readyAt).map(o=>(o.readyAt-ms(o))/6e4);
 $('#kpi').innerHTML=[['Orders',all.length],['Revenue','₹'+ok.reduce((s,o)=>s+o.total,0)],['Cancellation rate',(all.length?all.filter(o=>o.status=='cancelled').length/all.length*100:0).toFixed(1)+'%'],['Avg prep',pr.length?(pr.reduce((x,y)=>x+y)/pr.length).toFixed(1)+' min':'—']].map(k=>`<div class="col-6 col-lg-3"><div class="card stat p-3"><div class="small text-muted">${k[0]}</div><h4>${k[1]}</h4></div></div>`).join('');
 const dk=Object.keys(days);mk('c1','bar',dk,dk.map(k=>days[k].rev),'Revenue');mk('c2','line',dk,dk.map(k=>days[k].n),'Orders');
 mk('c3','doughnut',Object.keys(cat),Object.values(cat),'Items');mk('c4','bar',top.slice(0,7).map(x=>x[0]),top.slice(0,7).map(x=>x[1]),'Qty',true);mk('c5','bar',hr.map((_,i)=>i+':00'),hr,'Orders');
 const W={},M={};orders.filter(o=>o.status!='cancelled').forEach(o=>{const d=new Date(ms(o)),m=new Date(d);m.setDate(d.getDate()-((d.getDay()+6)%7));const w=key(m),mo=key(d).slice(0,7);W[w]=(W[w]||0)+o.total;M[mo]=(M[mo]||0)+o.total});
 const tb=(o,t)=>`<div class="col-md-4"><h6>${t}</h6>${Object.entries(o).sort().slice(-8).map(([k,v])=>`<div class="d-flex justify-content-between"><span>${k}</span><b>₹${v}</b></div>`).join('')||'—'}</div>`;
 $('#extra').innerHTML=`<div class="row">${tb(W,'Weekly revenue (week starting)')}${tb(M,'Monthly revenue')}<div class="col-md-4"><h6>Least ordered</h6>${top.slice(-5).reverse().map(x=>`<div>${esc(x[0])} (${x[1]})</div>`).join('')||'—'}<h6 class="mt-2">Top customers</h6>${Object.entries(cu).sort((x,y)=>y[1]-x[1]).slice(0,5).map(x=>`<div>${esc(x[0])} ₹${x[1]}</div>`).join('')||'—'}</div></div>`;
 rep={days,top,hr}}
$('#aexp').onclick=()=>{if(!rep.days)return;const wb=XLSX.utils.book_new(),add=(n,j)=>XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(j),n);
 add('Daily',Object.entries(rep.days).map(([d,v])=>({Date:d,Orders:v.n,Revenue:v.rev})));add('Items',rep.top.map(([n,q])=>({Item:n,Quantity:q})));add('Hours',rep.hr.map((n,h)=>({Hour:h+':00',Orders:n})));XLSX.writeFile(wb,'analytics_report.xlsx')};
/* ---------- Customers ---------- */
function rCust(){$('#cbody').innerHTML=users.filter(u=>u.role=='user').map(u=>{const o=orders.filter(x=>x.userId==u.id&&x.status!='cancelled');return`<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${esc(u.phone||'')}</td><td>${o.length}</td><td>₹${o.reduce((s,x)=>s+x.total,0)}</td></tr>`}).join('')}
go('dash');
