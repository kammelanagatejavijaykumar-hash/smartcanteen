import {initializeApp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {getAuth,onAuthStateChanged} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {getFirestore,doc,getDoc} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
export * from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
export * from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
const app=initializeApp({
  apiKey:"AIzaSyDUfxdjX_sQMfZo6BliUeaRzKRx0i4X0BY",authDomain:"smartcanteen-84737.firebaseapp.com",
  projectId:"smartcanteen-84737",storageBucket:"smartcanteen-84737.firebasestorage.app",
  messagingSenderId:"117953597711",appId:"1:117953597711:web:34276f784d58c07360ee7a"});
export const auth=getAuth(app),db=getFirestore(app);
export const $=s=>document.querySelector(s);
export const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function toast(m,t='success'){let c=$('#toasts');if(!c){c=document.createElement('div');c.id='toasts';document.body.append(c)}
  const d=document.createElement('div');d.className=`alert alert-${t} shadow`;d.textContent=m;c.append(d);setTimeout(()=>d.remove(),4000)}
export function go(t){document.querySelectorAll('.pane').forEach(p=>p.classList.toggle('on',p.id=='p-'+t));
  document.querySelectorAll('[data-t]').forEach(b=>b.classList.toggle('active',b.dataset.t==t))}
export function tabs(){document.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>go(b.dataset.t))}
export function guard(role,cb){onAuthStateChanged(auth,async u=>{
  if(!u){location='index.html';return}
  const s=await getDoc(doc(db,'users',u.uid));const p=s.data();
  if(!p){toast('Profile missing','danger');return}
  if(p.role!==role){location=p.role=='admin'?'admin.html':'customer.html';return}
  cb(u,p)})}
