import {auth,db,guard,$,esc,toast,go,tabs,collection,onSnapshot,query,where,addDoc,updateDoc,doc,serverTimestamp,signOut} from "./firebase.js";
const ST=['placed','confirmed','preparing','ready','completed'];
const LBL={placed:'Order Placed',confirmed:'Confirmed',preparing:'Preparing',ready:'Ready for Pickup',completed:'Completed',cancelled:'Cancelled'};
let U,P,menu=[],orders=[],cart=JSON.parse(localStorage.cart||'{}'),first=true;
const save=()=>localStorage.cart=JSON.stringify(cart);
const ms=o=>o.createdAt?.toMillis?.()||Date.now();
const today=()=>new Date().toLocaleDateString('en-CA');
tabs();
guard('user',(u,p)=>{U=u;P=p;$('#hello').textContent=p.name;$('#pname').value=p.name;$('#pphone').value=p.phone||'';
 onSnapshot(collection(db,'menuItems'),s=>{menu=s.docs.map(d=>({id:d.id,...d.data()})).filter(m=>!m.date||m.date==today());fillCats();renderMenu();renderCart()});
 onSnapshot(query(collection(db,'orders'),where('userId','==',u.uid)),s=>{
  if(!first)s.docChanges().forEach(c=>c.type=='modified'&&toast(`Order ${c.doc.data().orderNo}: ${LBL[c.doc.data().status]}`,'info'));first=false;
  orders=s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>ms(b)-ms(a));renderOrders()});
 setInterval(renderOrders,30000)});
$('#out').onclick=()=>signOut(auth).then(()=>location='index.html');
['q','cat','sp'].forEach(i=>$('#'+i).oninput=renderMenu);
function fillCats(){const c=$('#cat'),v=c.value;c.innerHTML='<option value="">All categories</option>'+[...new Set(menu.map(m=>m.category))].map(x=>`<option>${esc(x)}</option>`).join('');c.value=v}
function renderMenu(){const q=$('#q').value.toLowerCase(),c=$('#cat').value,sp=$('#sp').checked;
 const l=menu.filter(m=>(!c||m.category==c)&&(!sp||m.special)&&(m.name+' '+m.description).toLowerCase().includes(q)).sort((a,b)=>!!b.special-!!a.special);
 $('#menuGrid').innerHTML=l.length?l.map(m=>`<div class="col-6 col-md-4 col-lg-3"><div class="card food h-100"><img src="${esc(m.imageUrl||'https://placehold.co/400x250?text=Food')}" alt=""><div class="card-body d-flex flex-column"><div>${m.special?'<span class="badge bg-warning text-dark">⭐ Special</span> ':''}<span class="badge bg-secondary">${esc(m.category)}</span></div><h6 class="mt-2">${esc(m.name)}</h6><p class="small text-muted flex-grow-1">${esc(m.description)}</p><div class="d-flex justify-content-between align-items-center"><b>₹${m.price}</b>${m.available?`<button class="btn btn-sm btn-primary" data-add="${m.id}">Add</button>`:'<span class="badge bg-danger">Unavailable</span>'}</div></div></div></div>`).join(''):'<div class="empty"><i class="bi bi-egg-fried fs-1"></i><p>No items found</p></div>'}
const lines=()=>Object.entries(cart).map(([id,q])=>({m:menu.find(x=>x.id==id),q})).filter(l=>l.m);
function renderCart(){Object.keys(cart).forEach(id=>{if(!menu.find(m=>m.id==id))delete cart[id]});save();const L=lines();
 $('#cnt').textContent=L.reduce((a,l)=>a+l.q,0);$('#total').textContent=L.reduce((a,l)=>a+l.q*l.m.price,0);
 $('#cartList').innerHTML=L.length?L.map(l=>`<div class="d-flex align-items-center border-bottom py-2"><div class="flex-grow-1">${esc(l.m.name)} ${l.m.available?'':'<span class="badge bg-danger">Unavailable</span>'}<div class="small text-muted">₹${l.m.price} each</div></div><div class="btn-group btn-group-sm me-2"><button class="btn btn-outline-secondary" data-dec="${l.m.id}">−</button><span class="btn btn-light">${l.q}</span><button class="btn btn-outline-secondary" data-inc="${l.m.id}">+</button></div><b class="me-2">₹${l.q*l.m.price}</b><button class="btn btn-sm btn-outline-danger" data-del="${l.m.id}"><i class="bi bi-trash"></i></button></div>`).join(''):'<div class="empty"><i class="bi bi-cart-x fs-1"></i><p>Your cart is empty</p></div>'}
document.addEventListener('click',async e=>{const b=e.target.closest('[data-add],[data-inc],[data-dec],[data-del],[data-cancel],[data-reorder]');if(!b)return;const d=b.dataset;
 if(d.add||d.inc){const id=d.add||d.inc;cart[id]=(cart[id]||0)+1;if(d.add)toast('Added to cart')}
 else if(d.dec){cart[d.dec]--;if(cart[d.dec]<1)delete cart[d.dec]}
 else if(d.del)delete cart[d.del];
 else if(d.cancel){if(!confirm('Cancel this order?'))return;try{await updateDoc(doc(db,'orders',d.cancel),{status:'cancelled',cancelReason:'Cancelled by customer'});toast('Order cancelled')}catch(err){toast('Cannot cancel now (already being prepared)','danger')}return}
 else if(d.reorder){const o=orders.find(x=>x.id==d.reorder);let n=0;o.items.forEach(i=>{const m=menu.find(x=>x.id==i.id);if(m?.available){cart[m.id]=(cart[m.id]||0)+i.qty;n++}});toast(n?'Items added to cart':'Items no longer available',n?'success':'warning');if(n)go('cart')}
 save();renderCart()});
$('#place').onclick=async()=>{const b=$('#place'),L=lines();if(!L.length)return toast('Cart is empty','warning');
 if(L.some(l=>!l.m.available))return toast('Remove unavailable items first','warning');
 if(!confirm('Place this order?'))return;b.disabled=true;
 try{const no='ORD'+Date.now().toString(36).toUpperCase();
  await addDoc(collection(db,'orders'),{orderNo:no,userId:U.uid,userName:P.name,userEmail:P.email,items:L.map(l=>({id:l.m.id,name:l.m.name,category:l.m.category,price:l.m.price,qty:l.q})),total:L.reduce((a,l)=>a+l.q*l.m.price,0),status:'placed',etaMinutes:null,note:$('#note').value,createdAt:serverTimestamp()});
  cart={};$('#note').value='';save();renderCart();toast('Order '+no+' placed!');go('orders')}
 catch(err){toast(err.message,'danger')}b.disabled=false};
function renderOrders(){$('#orderList').innerHTML=orders.length?orders.map(o=>{const i=ST.indexOf(o.status),act=['placed','confirmed','preparing'].includes(o.status);
 let eta='';if(o.status=='placed')eta='Waiting for canteen confirmation';else if(act&&o.etaMinutes!=null)eta=`Estimated ${o.etaMinutes} min · <b>${Math.max(0,Math.ceil(o.etaMinutes-(Date.now()-o.etaSetAt)/6e4))} min remaining</b>`;else if(o.status=='ready')eta='🎉 Ready – please collect';
 return `<div class="card p-3 mb-3"><div class="d-flex justify-content-between"><b>${o.orderNo}</b><span class="badge bg-${o.status=='cancelled'?'danger':o.status=='completed'?'success':'warning text-dark'}">${LBL[o.status]}</span></div><div class="small text-muted">${new Date(ms(o)).toLocaleString()}</div>
 ${o.status=='cancelled'?`<div class="alert alert-danger my-2">Cancelled: ${esc(o.cancelReason||'')}</div>`:`<div class="steps">${ST.map((s,k)=>`<div class="step ${k<=i?'done':''}"><i>${k+1}</i>${LBL[s]}</div>`).join('')}</div><div class="mb-2">${eta}</div>`}
 <ul class="mb-2">${o.items.map(x=>`<li>${esc(x.name)} × ${x.qty} — ₹${x.price*x.qty}</li>`).join('')}</ul><div class="d-flex justify-content-between align-items-center"><b>Total ₹${o.total}</b><div>${['placed','confirmed'].includes(o.status)?`<button class="btn btn-sm btn-outline-danger" data-cancel="${o.id}">Cancel</button> `:''}<button class="btn btn-sm btn-outline-primary" data-reorder="${o.id}">Reorder</button></div></div></div>`}).join(''):'<div class="empty"><i class="bi bi-receipt fs-1"></i><p>No orders yet</p></div>'}
$('#psave').onclick=async()=>{const n=$('#pname').value.trim();if(n.length<2)return toast('Enter a valid name','warning');
 try{await updateDoc(doc(db,'users',U.uid),{name:n,phone:$('#pphone').value.trim()});P.name=n;$('#hello').textContent=n;toast('Profile saved')}catch(e){toast(e.message,'danger')}};
go('menu');
